package com.example.quizapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quizapp.R;
import com.example.quizapp.Registration;

public class loginquiz extends AppCompatActivity {

    EditText username, password;
    Button login, reg;
    boolean isPasswordVisible = false;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginquiz);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        reg = findViewById(R.id.reg);


        login.setOnClickListener(v -> {

            String user = username.getText().toString();
            String pass = password.getText().toString();

            if(user.isEmpty() || pass.isEmpty())
            {
                Toast.makeText(this,"Enter Username and Password",Toast.LENGTH_SHORT).show();
            }

            else
            {
                Toast.makeText(this,"Login Successful",Toast.LENGTH_SHORT).show();
            }
            Intent i=new Intent(loginquiz.this,category.class);
            startActivity(i);


        });


        reg.setOnClickListener(v -> {

            Intent i = new Intent(loginquiz.this, Registration.class);
            startActivity(i);

        });


        password.setOnTouchListener((v, event) -> {

            if(event.getAction() == MotionEvent.ACTION_UP)
            {
                if(event.getRawX() >= (password.getRight() - password.getCompoundDrawables()[2].getBounds().width()))
                {

                    if(isPasswordVisible)
                    {
                        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        password.setCompoundDrawablesWithIntrinsicBounds(R.drawable.password__2_,0,R.drawable.hidden,0);
                        isPasswordVisible = false;
                    }
                    else
                    {
                        password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                        password.setCompoundDrawablesWithIntrinsicBounds(R.drawable.password__2_,0,R.drawable.eye,0);
                        isPasswordVisible = true;
                    }

                    password.setSelection(password.getText().length());
                    return true;
                }
            }
            return false;

        });

    }
}