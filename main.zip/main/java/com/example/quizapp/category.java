package com.example.quizapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class category extends AppCompatActivity {

    Button logout;
    CardView cardJava, cardAndroid, cardCloud, cardGK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        logout = findViewById(R.id.logout);

        cardJava = findViewById(R.id.cardJava);
        cardAndroid = findViewById(R.id.cardAndroid);
        cardCloud = findViewById(R.id.cardCloud);
        cardGK = findViewById(R.id.cardGK);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(category.this);
                builder.setTitle("Logout");
                builder.setMessage("Are you sure you want to logout?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(category.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                        Intent i2 = new Intent(category.this, loginquiz.class);
                        startActivity(i2);
                        finish();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.show();
            }
        });

        cardAndroid.setOnClickListener(v -> {
            Intent intent = new Intent(category.this, android_questions.class);
            intent.putExtra("category","Android");
            startActivity(intent);
        });

        cardJava.setOnClickListener(v -> {
            Intent intent = new Intent(category.this, java_questions.class);
            intent.putExtra("category","Java");
            startActivity(intent);
        });

        cardCloud.setOnClickListener(v -> {
            Intent intent = new Intent(category.this, cloud_questions.class);
            intent.putExtra("category","Cloud");
            startActivity(intent);
        });

        cardGK.setOnClickListener(v -> {
            Intent intent = new Intent(category.this, general_questions.class);
            intent.putExtra("category","General");
            startActivity(intent);
        });
    }
}