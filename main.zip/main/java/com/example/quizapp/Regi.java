package com.example.quizapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Regi extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "regi.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "register";

    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_EMAIL = "email";
    private static final String COL_CONTACT = "contact";


    public Regi(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_PASSWORD + " TEXT, " +
                COL_USERNAME + " TEXT, " +
                COL_EMAIL + " TEXT, " +
                COL_CONTACT + " TEXT(10)) ";


        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert Method
    public boolean insertData(String username, String email,
                              String contact,String password) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);
        cv.put(COL_EMAIL, email);
        cv.put(COL_CONTACT, contact);


        long result = db.insert(TABLE_NAME, null, cv);

        return result != -1;
    }
    public boolean checkuser(String username, String password){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from "+TABLE_NAME+" where "+COL_USERNAME+" = ? AND "+COL_PASSWORD+" = ?" ,new String[]{username,password});
        boolean result=(cursor.getCount()>0);
        return result;
    }
}