package com.example.quizapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class practical_no18 extends AppCompatActivity {
Button login;
TextView t;
EditText user;
EditText pass;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_practical_no18);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        t=findViewById(R.id.t);
        pass=findViewById(R.id.pass);
        user=findViewById(R.id.user);
        login=findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String s,p;
                s=user.getText().toString();
                p=pass.getText().toString();
                if (s.equals("shreya")&& p.equals("1234"))
                {
                    Intent i=new Intent(practical_no18.this,simple.class);
                    startActivity(i);
                    Toast.makeText(practical_no18.this, "Login successfully", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(practical_no18.this, "Login faild", Toast.LENGTH_SHORT).show();
                    user.setText("");
                    pass.setText("");
                }


            }
        });

    }
}