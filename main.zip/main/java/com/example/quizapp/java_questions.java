package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class java_questions extends AppCompatActivity {

    RadioGroup q1group, q2group, q3group, q4group, q5group,
            q6group, q7group, q8group, q9group, q10group,
            q11group, q12group, q13group, q14group, q15group;

    Button submitBtn;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_questions);

        q1group = findViewById(R.id.q1group);
        q2group = findViewById(R.id.q2group);
        q3group = findViewById(R.id.q3group);
        q4group = findViewById(R.id.q4group);
        q5group = findViewById(R.id.q5group);
        q6group = findViewById(R.id.q6group);
        q7group = findViewById(R.id.q7group);
        q8group = findViewById(R.id.q8group);
        q9group = findViewById(R.id.q9group);
        q10group = findViewById(R.id.q10group);
        q11group = findViewById(R.id.q11group);
        q12group = findViewById(R.id.q12group);
        q13group = findViewById(R.id.q13group);
        q14group = findViewById(R.id.q14group);
        q15group = findViewById(R.id.q15group);

        submitBtn = findViewById(R.id.submitBtn);
        resultText = findViewById(R.id.resultText);

        submitBtn.setOnClickListener(v -> calculateScore());
    }

    private void calculateScore() {

        int score = 0;
        StringBuilder result = new StringBuilder();


        if(q1group.getCheckedRadioButtonId() == R.id.q1b){
            score++;
        } else {
            result.append("Q1 Wrong \nCorrect Answer: B) Object_Oriented\n\n");
        }


        if(q2group.getCheckedRadioButtonId() == R.id.q2a){
            score++;
        } else {
            result.append("Q2 Wrong \nCorrect Answer: B) Sun Microsystem\n\n");
        }

        if(q3group.getCheckedRadioButtonId() == R.id.q3c){
            score++;
        } else {
            result.append("Q3 Wrong \nCorrect Answer: C) main()\n\n");
        }


        if(q4group.getCheckedRadioButtonId() == R.id.q4b){
            score++;
        } else {
            result.append("Q4 Wrong \nCorrect Answer: C) extends\n\n");
        }


        if(q5group.getCheckedRadioButtonId() == R.id.q5c){
            score++;
        } else {
            result.append("Q5 Wrong \nCorrect Answer: B) Polymorphism\n\n");
        }


        if(q6group.getCheckedRadioButtonId() == R.id.q6b){
            score++;
        } else {
            result.append("Q6 Wrong \nCorrect Answer: C) java.util\n\n");
        }


        if(q7group.getCheckedRadioButtonId() == R.id.q7c){
            score++;
        } else {
            result.append("Q7 Wrong \nCorrect Answer: D) All of these\n\n");
        }


        if(q8group.getCheckedRadioButtonId() == R.id.q8c){
            score++;
        } else {
            result.append("Q8 Wrong \nCorrect Answer: C) Integer()\n\n");
        }


        if(q9group.getCheckedRadioButtonId() == R.id.q9b){
            score++;
        } else {
            result.append("Q9 Wrong \nCorrect Answer: B) java.lang\n\n");
        }


        if(q10group.getCheckedRadioButtonId() == R.id.q10b){
            score++;
        } else {
            result.append("Q10 Wrong \nCorrect Answer: B) JVM\n\n");
        }


        if(q11group.getCheckedRadioButtonId() == R.id.q11a){
            score++;
        } else {
            result.append("Q11 Wrong \nCorrect Answer: D) Compilation\n\n");
        }
        if(q12group.getCheckedRadioButtonId() == R.id.q12c){
            score++;
        } else {
            result.append("Q12 Wrong \nCorrect Answer: A) parseInt\n\n");
        }


        if(q13group.getCheckedRadioButtonId() == R.id.q13c){
            score++;
        } else {
            result.append("Q13 Wrong \nCorrect Answer: A) equals()\n\n");
        }


        if(q14group.getCheckedRadioButtonId() == R.id.q14c){
            score++;
        } else {
            result.append("Q14 Wrong \nCorrect Answer: C) finally()\n\n");
        }


        if(q15group.getCheckedRadioButtonId() == R.id.q15c){
            score++;
        } else {
            result.append("Q15 Wrong \nCorrect Answer: B) boolean\n\n");
        }
        String finalResult = "Your Score: " + score + "/15\n\n" + result.toString();

        Intent intent = new Intent(java_questions.this, result.class);
        intent.putExtra("result", finalResult);
        startActivity(intent);



    }
}