package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class email extends AppCompatActivity {
    Button e;
    EditText msg,sub,receiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_email);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        e=findViewById(R.id.e);
        msg=findViewById(R.id.msg);
        sub=findViewById(R.id.sub);
        receiver=findViewById(R.id.receiver);
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String m,s,r;
                m=msg.getText().toString();
                s=sub.getText().toString();
                r=receiver.getText().toString();

                Intent i=new Intent(Intent.ACTION_SEND);
                i.putExtra("receiver",new String[]{r});
                i.putExtra("sub",s);
                i.putExtra("msg",m);
                i.setType("message/rfc822");
                startActivity(Intent.createChooser(i,"Choose email client"));
                Toast.makeText(email.this, "Email Send successfully", Toast.LENGTH_SHORT).show();


            }
        });
    }
}