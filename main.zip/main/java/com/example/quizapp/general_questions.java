package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class general_questions extends AppCompatActivity {

    RadioGroup q1group, q2group, q3group, q4group, q5group,
            q6group, q7group, q8group, q9group, q10group,
            q11group, q12group, q13group, q14group, q15group;

    Button submitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_questions);

        q1group = findViewById(R.id.q1group);
        q2group = findViewById(R.id.q2group);
        q3group = findViewById(R.id.q3group);
        q4group = findViewById(R.id.q4group);
        q5group = findViewById(R.id.q5group);
        q6group = findViewById(R.id.q6group);
        q7group = findViewById(R.id.q7group);
        q8group = findViewById(R.id.q8group);
        q9group = findViewById(R.id.q9group);
        q10group = findViewById(R.id.q10group);
        q11group = findViewById(R.id.q11group);
        q12group = findViewById(R.id.q12group);
        q13group = findViewById(R.id.q13group);
        q14group = findViewById(R.id.q14group);
        q15group = findViewById(R.id.q15group);

        submitBtn = findViewById(R.id.submitBtn);

        submitBtn.setOnClickListener(v -> calculateScore());
    }

    private void calculateScore() {

        int score = 0;
        StringBuilder result = new StringBuilder();

        if(q1group.getCheckedRadioButtonId() == R.id.q1c){
            score++;
        } else {
            result.append("Q1 Wrong\nCorrect Answer: C) Jupiter\n\n");
        }

        if(q2group.getCheckedRadioButtonId() == R.id.q2b){
            score++;
        } else {
            result.append("Q2 Wrong\nCorrect Answer: B) Nile\n\n");
        }

        if(q3group.getCheckedRadioButtonId() == R.id.q3group){
            score++;
        } else {
            result.append("Q3 Wrong\nCorrect Answer: B) Alexander Graham Bell\n\n");
        }

        if(q4group.getCheckedRadioButtonId() == R.id.q4b){
            score++;
        } else {
            result.append("Q4 Wrong\nCorrect Answer: B) Pacific Ocean\n\n");
        }
        if(q5group.getCheckedRadioButtonId() == R.id.q5a){
            score++;
        } else {
            result.append("Q5 Wrong\nCorrect Answer: A) Dr. Rajendra Prasad\n\n");
        }
        if(q6group.getCheckedRadioButtonId() == R.id.q6a){
            score++;
        } else {
            result.append("Q6 Wrong\nCorrect Answer: A) Indian Space Research Organisation\n\n");
        }

        if(q7group.getCheckedRadioButtonId() == R.id.q7c){
            score++;
        } else {
            result.append("Q7 Wrong\nCorrect Answer: C) Asia\n\n");
        }
        if(q8group.getCheckedRadioButtonId() == R.id.q8b){
            score++;
        } else {
            result.append("Q8 Wrong\nCorrect Answer: B) Yen\n\n");
        }
        if(q9group.getCheckedRadioButtonId() == R.id.q9c){
            score++;
        } else {
            result.append("Q9 Wrong\nCorrect Answer: C) Kidney\n\n");
        }
        if(q10group.getCheckedRadioButtonId() == R.id.q10c){
            score++;
        } else {
            result.append("Q10 Wrong\nCorrect Answer: C) Banyan\n\n");
        }
        if(q11group.getCheckedRadioButtonId() == R.id.q11b){
            score++;
        } else {
            result.append("Q11 Wrong\nCorrect Answer: B) Femur\n\n");
        }

        if(q12group.getCheckedRadioButtonId() == R.id.q12a){
            score++;
        } else {
            result.append("Q12 Wrong\nCorrect Answer: A) Greenland\n\n");
        }

        if(q13group.getCheckedRadioButtonId() == R.id.q13b){
            score++;
        } else {
            result.append("Q13 Wrong\nCorrect Answer: B) Jaipur\n\n");
        }
        if(q14group.getCheckedRadioButtonId() == R.id.q14c){
            score++;
        } else {
            result.append("Q14 Wrong\nCorrect Answer: C) Thomas Edison\n\n");
        }
        if(q15group.getCheckedRadioButtonId() == R.id.q15d){
            score++;
        } else {
            result.append("Q15 Wrong\nCorrect Answer: D) Bharat Ratna\n\n");
        }
        String finalResult = "Your Score: " + score + "/15\n\n" + result.toString();
        Intent intent = new Intent(general_questions.this, result.class);
        intent.putExtra("result", finalResult);
        startActivity(intent);
    }
}