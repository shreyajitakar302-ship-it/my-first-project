package com.example.quizapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Registration extends AppCompatActivity {

    EditText username, email, contact, password;

    Button reg;

    Regi db=new Regi(this);

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);



       username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        contact = findViewById(R.id.contact);
        reg = findViewById(R.id.reg);

        reg.setOnClickListener(v -> {

            String n = username.getText().toString().trim();
            String p = password.getText().toString().trim();
            String e = email.getText().toString().trim();
            String c = contact.getText().toString().trim();

            if(n.isEmpty() || e.isEmpty() || c.isEmpty()  || p.isEmpty()){
                Toast.makeText(this,"Please Fill All Fields",Toast.LENGTH_SHORT).show();
                return;
            }
            boolean check = db.insertData(n,e,c,p);

            if(check){
                Toast.makeText(this,"Data Inserted Successfully",Toast.LENGTH_SHORT).show();
                clearFields();
                Intent i=new Intent(Registration.this,loginquiz.class);
                startActivity(i);
            } else {
                Toast.makeText(this,"Data Not Inserted",Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void clearFields(){
        username.setText("");
        email.setText("");
        contact.setText("");
        password.setText("");

    }
}